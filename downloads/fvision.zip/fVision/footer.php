<!-- begin footer -->
</div>
<div id="footer">
		<p>
			Using the fVision theme design by <a href="http://www.fahlstad.se/">Fredrik Fahlstad </a>
			Proudly powered by <a href="http://www.wordpress.org" title="Wordpress CMS">WordPress</a>.</p>
</div>

<?php do_action('wp_footer'); ?>


<script type="text/javascript">
//<![CDATA[
/* Replacement calls. Please see documentation for more information. */

if(typeof sIFR == "function"){

// This is the preferred "named argument" syntax
	sIFR.replaceElement(named({sSelector:"h1#blogname", sFlashSrc:"<?php bloginfo('template_url'); ?>/avant.swf", sColor:"#91B476", sLinkColor:"#91B476", sBgColor:"#FFFFFF", sHoverColor:"#CCCCCC", nPaddingTop:0, nPaddingBottom:0, sFlashVars:"textalign=left&offsetTop=0", sWmode:"transparent"}));


};

//]]>
</script>






</body>
</html>
