<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<h2> <?php the_date() ?> </h2> 

<h3><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a> 

</h3><?php the_time('F dS Y') ?>

Posted to <?php the_category(',') ?>

<?php the_content(__('(Read the article)')); ?>

<?php $comments_img_link = '<img src="' . get_stylesheet_directory_uri() . '/images/comments.gif" title="comments" alt="*" />';
comments_popup_link(' Comments(0)', $comments_img_link . ' Comments(1)', $comments_img_link . ' Comments(%)'); ?>

<?php trackback_rdf(); ?>

<?php comments_template(); 

endwhile; else: ?>

<?php _e('Sorry, no posts matched your criteria.'); ?>
<?php endif; ?>

<?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?>
</div>
<?php get_sidebar(); ?>

<?php get_footer(); ?>