<div id="footer">
	<p><a href="http://www.fahlstad.se>"Fahlstad.se</a></p>
</div>
</div>
<?php do_action('wp_footer'); ?>
</body>
</html>