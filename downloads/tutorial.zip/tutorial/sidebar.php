<div id="sidebar">
<?php wp_list_pages('depth=1&title_li=<h2>' . __('Pages') . '</h2>' ); ?>

<li>
  <h2><?php _e('Archives'); ?></h2>
  <ul>
    <?php wp_get_archives('type=monthly'); ?>
  </ul>
</li>
<li>
  <h2><?php _e('Categories'); ?></h2>
  <ul>
    <?php list_cats(0, '', 'name', 'asc', '', 1, 0, 1, 1, 1, 1, 0,'','','','','') ?>
  </ul>
</li>

  <h2><?php _e('Meta'); ?> </h2>
  <ul>
    <?php wp_register(); ?>
    <li><a href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>">
      <?php _e('<abbr title="Really Simple Syndication">RSS</abbr>'); ?></a>
	 </li>
    <li>
      <?php wp_loginout(); ?>
    </li>
    <?php wp_meta(); ?>
  </ul>
</li>
</ul>
</div>
