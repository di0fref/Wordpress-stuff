<?php get_header();?>


	<h1>The page you requested is no longer here [error 404] </h1>
	<p>... but we think we can help you </p>

We suggest you try one of the links below: 
<p><a href="<?php bloginfo('siteurl');?>">Home Page</a></p>
    <h2>Help us to help you ... </h2>
    <p>In order to improve our service, you can inform us that someone else has an incorrect link to our site. </p>
    <p>&nbsp;</p>
	  </div>
    <?php get_sidebar(); ?>
	</div>
<?php get_footer(); ?>
    
