	</div> <!-- end wrapper -->

	<div id="footer"><p>Theme by: <a href="http:www.fahlstad.se">Fredrik Fahlstad</a><br />Powered by Wordpress</p></div>
	
<?php wp_footer(); ?>
</body>
</html>
