<?php get_header(); ?>

<?php if (have_posts()) : ?>

	<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
	<?php 
	if (is_category()) { ?>				
		<div class="arc"><h2>Archive for the '<?php echo single_cat_title(); ?>' Category</h2></div>
	<?php }
	 
	elseif (is_day()) { ?>
		<div class="arc">Archive for <?php the_time('F jS, Y'); ?></h2></div>
	<?php }
	
	elseif (is_month()) { ?>
		<div class="arc"><h2>Archive for <?php the_time('F, Y'); ?></h2></div>
	<?php } 
	
	elseif (is_year()) { ?>
		<div class="arc"><h2>Archive for <?php the_time('Y'); ?></h2></div>
	<?php } 
	
	elseif (is_search()) { ?>
		<div class="arc"><h2>Search Results</h2></div>
	<?php } 
	
	elseif (is_author()) { ?>
		<div class="arc"><h2>Author Archive</h2></div>
	<?php }
	 
	elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
		<div class="arc"><h2>Blog Archives</h2></div>
	<?php } ?>

<?php while (have_posts()) : the_post(); ?>

<div class="entry">
  <h2 class="entrydate">
    <?php the_date() ?>
  </h2>   <h3 class="entrytitle" id="post-<?php the_ID(); ?>"> <a href="<?php the_permalink() ?>" rel="bookmark">
    <?php the_title(); ?>
    </a> </h3>    <div class="entrymeta">
      <?php the_time('F dS Y') ?>
      Posted to
      <?php the_category(',') ?>
      <?php edit_post_link(__('<strong>Edit</strong>')); ?>
    </div>

  <div class="entrybody">
    <?php
			the_content(__('(Read the article)')); 
		?>
    <p class="comments_link">
      <?php 
		$comments_img_link = '<img src="' . get_stylesheet_directory_uri() . '/images/comments.gif"  title="comments" alt="*" />';
		comments_popup_link(' Comments(0)', $comments_img_link . ' Comments(1)', $comments_img_link . ' Comments(%)'); 
	?>
    </p>
  </div>
  <!--
	<?php trackback_rdf(); ?>
	-->
</div>
<?php comments_template(); // Get wp-comments.php template 
 endwhile; else: ?>
<p class="pageing">
  <?php _e('Sorry, no posts matched your criteria.'); ?>
</p>
<?php endif; ?>
<p class="pageing"><?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?>
</p>
</div>
<?php get_sidebar(); ?>
<!-- The main column ends  -->
<?php get_footer(); ?>
