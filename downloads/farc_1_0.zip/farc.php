<?PHP
/*
Plugin Name: fArc
Plugin URI: http://www.fahlstad.se
Description: Adds more infonmation to the archive.
Author: Fredrik Fahlstad
Version: 1.1
Author URI: http://www.fahlstad.se
*/


function farc_wp_head(){
	?>
	
<style type="text/css">
	ul.farc{
	}
	ul.farc li{
		}
	ul.farc li a{
	}
</style>
	<?php
}

function farc_get_comment_count($id) {
    global $wpdb, $table_prefix;
	$table = $table_prefix."comments";
	$sql = "SELECT COUNT(*) FROM $table WHERE comment_post_ID = '$id'";
    return $wpdb->get_var($sql);
}

function farc_the_content($content){
if(!preg_match("|<!--farc-->|",$content))
			return $content;
	global $wpdb, $month;
	$now = current_time('mysql');
	$results = $wpdb->get_results("SELECT DISTINCT YEAR(post_date) AS year, MONTH(post_date) AS month, count(ID) as posts FROM " . $wpdb->posts . " WHERE post_date <'" . $now . "' AND post_status='publish' AND post_password='' GROUP BY YEAR(post_date), MONTH(post_date) ORDER BY post_date DESC");


	foreach($results as $result){
		$url = get_month_link($result->year, $result->month);
		$fyear = $result->year;
		$fmonth = zeroise($result->month,2);
        $linktext = sprintf('%s %d', $month[zeroise($result->month,2)], $result->year);
        $farc .= get_archives_link($url, $linktext, '','<h4>','</h4>');
		
		$res = $wpdb->get_results("SELECT ID, post_date, post_title, comment_status FROM " . $wpdb->posts . " WHERE post_date LIKE '$fyear-$fmonth-%' AND post_date <'" . $now . "' AND post_status='publish' AND post_password='' ORDER BY post_date DESC");
		
		$farc .= "<ul class='farc'>";
		foreach((array)$res as $r){
			$farc .= "<li>".mysql2date("jS", $r->post_date)." <a href='".get_permalink($r->ID)."'>$r->post_title.</a><span> (".farc_get_comment_count($r->ID).")</span></li>";
		}
		$farc .= "</ul>";

		
	}
	
	return preg_replace("|<!--farc-->|", $farc, $content);
}	
	add_filter('wp_head', 'farc_wp_head');
    add_filter('the_content', 'farc_the_content');

?>