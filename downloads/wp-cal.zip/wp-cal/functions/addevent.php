<?php
include("../../../../wp-blog-header.php");
include( 'functions.php' );
global $wpdb, $tabl;

if(isset($_POST['action']) && $_POST['action'] == 'doadd'){
	
	$sql = "INSERT INTO $table (title, description, date, start_time, end_time)
											VALUES(	'$_POST[title]',
															'$_POST[description]',
															'$_POST[date]',
															'$_POST[start_time]',
															'$_POST[end_time]'
														)";
	$wpdb->query($sql);
	echo "<p>Event added successfully</p>";
}
else{?>
<h4>Add event <?php echo date($dateformat, $_GET['date']);?></h4>

<form method="post" action="" id="addform" onsubmit = 'doadd();return false;'>

	<div class="row">
		<span class="label">Title:</span>
		<span class="formw"><input type="text" size="25" id="title" value=""/>
		<div id="titleerror" class="error"></div>
		</span>
	</div>
	
	<div class="row">
		<span class="label">Start time:</span>
		<span class="formw"><input type="text" size="25" id="start_time" value="" />
		<div id="starterror" class="error"></div>
		</span>
	</div>
	
	<div class="row">
		<span class="label">End time:</span>
		<span class="formw"><input type="text"  size="25" id="end_time"  value=""/>
		<div id="enderror" class="error"></div>
		</span>
	</div>
	
	<div class="row">
		<span class="label">Description:</span>
		<span class="formw"><textarea id="description" cols="25" rows="8"></textarea></span>
	</div>
	
	<input type="hidden" id="date" value="<?php echo $_GET['date'];?>" />
	
	<div class="row">
		<span class="formw"><input type="submit" value="Add event"></span>
	</div>
	
</form>
<?php }?>