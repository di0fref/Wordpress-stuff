<?php
include( '../../../../wp-blog-header.php' );
echo "<style type='text/css' media='screen'>";

if(get_option('cal_where')== "side"){
	echo "#cal{
		float:left;
		width:58%;
		background:#edf2ff;
		padding:1%;
		border:#dce6ff solid 1px;
		margin-bottom:1em;
		display:none;
	}
	#calext{
		float:left;
		margin:0 0 1em 1%;
		background:#edf2ff;
		padding:1%;
		border:#dce6ff solid 1px;
		width:36%;
		display:none;
	}	#msg{
			float:left;
			margin-left:1%;
			background:#edf2ff;
			padding:1%;
			border:#dce6ff solid 1px;
			width:36%;
			margin-bottom:1%;
			font-weight:bold;
			display:none;
		}";
}
else{
	echo "
	#cal{
		background-color:#edf2ff;
	}
	#calext{
		
		display:none;
	}	
	#msg{
		display:none;
		}\n";
}
echo "table.calendar {
	border-collapse:collapse;
	width:100%;
} 
td.days{
	height:70px;
	border:#B5C9FD solid 1px;
	padding:5px;
	background:#fff;
}
td.days ul{
	margin:0;
	padding:0;
	list-style-type:none;
}
td.days ul li {
	padding-bottom:15px;
	line-height:110%;
}
table.calendar th{
	padding:3px;	
}
td.today { 
	color: #000000; 
	background: #ebf3fb;
	font-weight: bold;
}

table.calnav{
	width:100%;
}
ul#calday{
	margin:0;
	padding:0;
	list-style-type:none;
}

ul#calday li{
	background: #fff;
	margin-bottom:3px;
	border:#dce6ff solid 1px;
	
	padding:8px;
}
ul#calday{
	
}

td.events{
	background: #ccc;
	
}
div.row {
  clear: both;
  padding-top: 10px;
  }

div.row span.label {
  float: left;
  width: 30%;
  text-align: right;
  }

div.row span.formw {
  float: right;
  width: 70%;
  text-align: left;
  }

#msg p{
	margin:0;
}
#calday h4{
}
.error{
	font-weight:bold;
	color:red;
	display:inline;
}
#error{
	background:#edf2ff;
	padding:1%;
	border:#dce6ff solid 1px;
	margin:1% 0 1% 0;
	font-weight:bold;
	color:red;
	display:none;
}
#calloginform{
	margin-bottom:2em;
}
</style>";
?>