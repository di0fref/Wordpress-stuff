<?php
include("../../../../wp-blog-header.php");
include( 'functions.php' );

global $wpdb, $post, $user_id, $table;
$id = $_GET['id'];
$now = mktime(0,0,0,date('m'), date('d'), date('Y')); 
	$event = $wpdb->get_row("SELECT * FROM $table WHERE id = '$id'");
	if($now == $event->date )
		echo "<h4>Today</h4>";
	else
		echo "<h4>".date($dateformat, $event->date)."</h4>";
	
	get_currentuserinfo();
	if(user_can_edit_post($user_ID, $post->ID)){
		$canedit = true;
		echo "<a href='javascript:onclick=addevent($_GET[date]);' style='float:right'>Add event</a><div class='clear'></div>";
	}
	echo "<ul id='calday'>";
	
		if($canedit){
			$edit = "<a href='javascript:onclick=editevent($event->id,$_GET[date]);'>Edit |</a>";
			$del = "<a href='javascript:onclick=delevent($event->id,$_GET[date]);'>Delete</a>";
		}
					echo "<li class='event' id='event-$event->id'>
									<h4>$event->title</h4>
									<span style='float:right'>$edit $del</span>
									<div class='clear'></div>
									<b>Time:</b> $event->start_time - $event->end_time<br />
									<b>Description:</b> $event->description
								</li>";
		

	echo "</ul>";

?>