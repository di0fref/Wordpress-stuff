<?php
include("../../../../wp-blog-header.php");
include( 'functions.php' );

global $wpdb, $post, $user_id, $table;
if($_GET['date'] == "false" )
	$d = mktime(0,0,0,date('m'), date('d'), date('Y')); 
else
	$d = $_GET['date'];

$now = mktime(0,0,0,date('m'), date('d'), date('Y')); 
	$events = $wpdb->get_results("SELECT * FROM $table WHERE date = '$d' ORDER BY start_time ASC");
	if($_GET['date'] == "false" || $now == $d)
		echo "<h4>Today's events</h4>";
	else
		echo "<h4>".date($dateformat, $d)."</h4>";
	
	if(!$events){
		echo "<p>No events this day</p>";
	}
	get_currentuserinfo();
	if(user_can_edit_post($user_ID, $post->ID)){
		$canedit = true;
		echo "<a href='javascript:onclick=addevent($d);' style='float:right'>Add event</a><div class='clear'></div>";
	}
	echo "<ul id='calday'>";
	
	foreach((array)$events as $event){
		if($canedit){
			$edit = "<a href='javascript:onclick=editevent($event->id,$d);'>Edit |</a>";
			$del = "<a href='javascript:onclick=delevent($event->id,$d);'>Delete</a>";
		}
					echo "<li class='event' id='event-$event->id'>
									<h4>$event->title</h4>
									<span>$edit $del</span>
									<div class='clear'></div>
									<b>Time:</b> $event->start_time - $event->end_time<br />
									<b>Description:</b> $event->description
								</li>";
		
	}
	echo "</ul>";

?>