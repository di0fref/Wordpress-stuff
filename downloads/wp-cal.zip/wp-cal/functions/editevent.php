<?php
include("../../../../wp-blog-header.php");
include( 'functions.php' );

global $wpdb, $table, $table;
if(isset($_POST['action']) && $_POST['action'] == 'doedit'){
	$wpdb->query("UPDATE $table SET title = '$_POST[title]', 
												description = '$_POST[description]', 
												start_time = '$_POST[start_time]', 
												end_time = '$_POST[end_time]'
												WHERE id = '$_POST[id]'");
	echo "<p>Update successful</p>";
}
else{
	$id = $_GET['id'];
	$event = $wpdb->get_row("SELECT * FROM $table WHERE id = $id"); ?>
	<h4>Edit event <?php echo $event->title;?></h4>
	<form method="post" action="" id="editform" onsubmit = "return doedit();">
	
		<div class="row">
			<span class="label">Title:</span>
			<span class="formw"><input type="text" size="25" id="title" value="<?php echo $event->title;?>"/>
			<div id="titleerror" class="error"></div>
			</span>
		</div>
		
		<div class="row">
			<span class="label">Start time:</span>
			<span class="formw"><input type="text" size="25" id="start_time" value="<?php echo $event->start_time;?>" />
			<div id="starterror" class="error"></div>
			</span>
		</div>
		
		<div class="row">
			<span class="label">End time:</span>
			<span class="formw"><input type="text"  size="25" id="end_time"  value="<?php echo $event->end_time;?>"/>
			<div id="enderror" class="error"></div>
			</span>
		</div>
		
		<div class="row">
			<span class="label">Description:</span>
			<span class="formw"><textarea id="description" cols="25" rows="8"><?php echo $event->description;?></textarea></span>
		</div>
		
		<input type="hidden" id="id" value="<?php echo $event->id;?>" />
		<input type="hidden" id="date" value="<?php echo $event->date;?>" />
		
		<div class="row">
			<span class="formw"><input type="submit" value="Edit"></span>
		</div>
		
	</form>
<?php } ?>
