<!-- begin footer -->
</div>

<div id="footer">
		<p>
			&copy;Copyright Fredrik Fahlstad 2005. Using the fGlare theme by <a href="http://www.fahlstad.se">Fredrik Fahlstad</a><br />
</p></div>
</div>
<?php do_action('wp_footer'); ?>
</body>
</html>