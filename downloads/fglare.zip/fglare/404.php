<?php get_header();?>

<div id="content">
	<h3>The page you requested is no longer here [error 404] </h3>
	<p>... but we think we can help you </p>

We suggest you try one of the links below: 
<ul>
<li><a href="<?php bloginfo('siteurl');?>">Home Page</a></li>

	  </div>
    <?php get_sidebar(); ?> 
      <?php get_footer(); ?> 
    
