<?php

		$path = get_option('siteurl') . '/wp-admin/admin.php?page=fquick-options.php'; // Form Action URI

		// Add some options
		add_option('fquick_number_to_show','10');
		
		// Check if updating
		if (isset($_POST['info_update'])){
		
			// Update options
			update_option('fquick_number_to_show', $_POST['fquick_number_to_show']);
			?>
			<div class="updated">
			  <p>Options successfully updated.</p>
			</div>
			<?php
		}
		
		$number = stripslashes(get_option('fquick_number_to_show'));
		
		?>
		<div class=wrap>
		<form method="post" action="<?php echo $path ?>">
		<h2>fQuick options</h2>
		<fieldset name="set1">
			<legend>Limit number of fQuicks to output. Zero (0) = show all. </legend>
				<table width="306" border="0">
				<tr>
				  <td valign="top">&nbsp;</td>
				  <td valign="top">&nbsp;</td>
				  </tr>
				<tr>
				<td width="36"><div align="right"><strong>Limit:</strong></div></td>
				<td width="209"><input name="fquick_number_to_show" size="10" value="<?php echo stripslashes($number); ?>" /></td>
				</tr>
				<tr>
				  <td valign="top">&nbsp;</td>
				  <td valign="top">&nbsp;</td>
				  </tr>
		</table>
		</fieldset>
			<div class="submit">
				<input type='submit' name='info_update' value='Update options &raquo;'/>
		</div>
		</form>
	
	<?php

		

?>