<?php
	$path = get_option('siteurl') . '/wp-admin/admin.php?page=fquick-manage.php'; // Form Action URI
	global $wpdb, $table_prefix;
	$table = $table_prefix."fquick";
	
	// Edit the note
	if(isset($_POST['fquick_do_edit'])){
		
		$url = addslashes(htmlentities(trim($_POST['fquick_url'])));
		$title = addslashes($_POST['fquick_title']);
		$desc = addslashes($_POST['fquick_desc']);
		$id = $_POST['fquick_do_edit_id'];
		
		$sql_do_edit = "UPDATE $table SET 
							url = '$url', 
							title = '$title', 
							description = '$desc' 
						WHERE id = '$id'";
		$wpdb->query($sql_do_edit);
	}

	// Delete note from database
	if(isset($_POST['fquick_delete'])){
		
		$fquick_delete_id = $_POST['fquick_delete_id'];
		$sql_del = "DELETE FROM $table WHERE id = $fquick_delete_id";
		$wpdb->query($sql_del);
	}
	
	// Add new note to database
	if(isset($_POST['fquick_add'])){
		
		$fquick_title = addslashes($_POST['fquick_title']);
		$fquick_desc = addslashes($_POST['fquick_desc']);
		$fquick_url = addslashes(htmlentities(trim($_POST['fquick_url'])));
		// Check http://
		if(substr($fquick_url,0,7) != 'http://')
			$fquick_url = "http://".$fquick_url;
		$sql_add = "INSERT INTO $table (url, title, description) VALUES('$fquick_url', '$fquick_title', '$fquick_desc')";
		$wpdb->query($sql_add);	
	}
	
	// Print message
	if(isset($_POST['fquick_do_edit'])){
		?>
			<div class="updated">
			  <p>fQuick note sucessfully updated.</p>
			</div>
			<?php 
	}
	if(isset($_POST['fquick_add'])){
		?>
			<div class="updated">
			  <p>fQuick note added sucessfully.</p>
			</div>
			<?php 
	}
	if(isset($_POST['fquick_delete'])){
		?>
			<div class="updated">
			  <p>fQuick note sucessfully deleted.</p>
			</div>
			<?php 
	}
		?>	
	
	<div class=wrap>
		<form method="post" action="<?php echo $path ?>">
		<?php 
		
		if(!isset($_POST['fquick_edit'])) 
			echo "<h2>Add fQuick</h2>";
		
		else {
			echo "<h2>Edit fQuick</h2>";
			$sql_edit = "SELECT * FROM $table WHERE id = $_POST[fquick_edit_id]";
			$fquick_edit_row = $wpdb->get_row($sql_edit);
		}
		
		?>
		<fieldset name="set1">
			</legend>
				<table width="200" border="0">
				<tr>
				<td><div align="right"><strong>Title:</strong></div></td>
				<td><input name="fquick_title" size="32" value="<?php echo stripslashes($fquick_edit_row->title); ?>" /></td>
				</tr>
				<tr>
				<td><div align="right"><strong>URL:</strong></div></td>
				<td><input name="fquick_url" size="32" value="<?php echo stripslashes($fquick_edit_row->url); ?>"/></td>
				</tr>
				<tr>
				<td height="24" valign="top"><div align="right"><strong>Description:</strong></div></td>
				<td><textarea name="fquick_desc" cols="30" rows="4" ><?php echo stripslashes($fquick_edit_row->description); ?></textarea></td>
				</tr>
				</table>
		</fieldset>
			<div class="submit">
			<?php if(!isset($_POST['fquick_edit'])) 
				echo "<input type='submit' name='fquick_add' value='Add note &raquo;'/>";
			else
				echo "<input type='submit' name='fquick_do_edit' value='Edit note &raquo;'/>
					<input type='hidden' name='fquick_do_edit_id' value='$fquick_edit_row->id' />";

		?>		
		</div>
		</form>
	
	<?php
	
	if(!isset($_POST['fquick_edit']))
	{
		// Get all notes to display
		$sql_get = "SELECT * FROM $table ORDER BY date DESC";
		$fquick_res = $wpdb->get_results($sql_get);
	
		// Show the notes
		$alternate = 0;
		
		echo "<h2>All fQuicks</h2>";	
		echo "<table border = '0' width='100%' cellpadding='3' cellspacing='3'>
		
		<tr>
		<th>ID</th>
		<th>Title</th>
		<th>Description</th>
		<th>URL</th>
		<th>&nbsp;</th>
		<th>&nbsp;</th>
		</tr>";
		
		foreach($fquick_res as $res){
			
			if($alternate%2 == 0)
				echo "<tr class='alternate'>";
			else
				echo "<tr class=''>";
				
			echo "<td><strong>$res->id</strong></td>
					<td>".stripslashes($res->title)."</td>
					<td>".stripslashes($res->description)."</td>
					<td>".stripslashes($res->url)."</td>
					<td>
					<form action='$path' method='post'>
						<input type='submit' name='fquick_edit' value='Edit'/>
						<input name='fquick_edit_id' type='hidden' value='$res->id'/>
					</form>
					</td>
					<td>
					<form action='$path' method='post'>
						<input type='submit' name='fquick_delete' value='Delete'/>
						<input name='fquick_delete_id' type='hidden' value='$res->id'/>
					</form>
					</td>
					</tr>";
			++$alternate;
		}
		echo "</table></div>";
	}

?>
