<?php
/*
Plugin Name: fQuick
Plugin URI: http://www.fahlstad.se
Description: A plugin that lets you post quick sidenotes with links on your blog
Author: Fredrik Fahlstad
Version: 1.2
Author URI: http://www.fahlstad.se
*/

	// Add this to the admin head
	//function fquick_adminhead(){
	//}
	
	
	function fquick_wphead() {
	?>
	
<style type="text/css">
/*
#fquick{
	margin:0;
}
#fquick .section{
	margin:10px 0;
}

#fquick p.fquick-date{
	margin: 0px 0px 0px;
	padding: 0px;
	font-size: 85%;
	color:#4b5ba2
}
#fquick p.fquick-link{
	margin: 0px 0px 3px;
	padding: 0px;
}
#fquick p.fquick-desc{
	margin: 0px;
	padding: 0px;
	line-height:160%;

}
*/
</style>
		
		<?php
		echo "<link rel='alternate' type='application/rss+xml' title='SideNotes' href='".get_bloginfo('siteurl')."/fquick_feed.php' />";
	}
	// fQuick archive
	function fquick_the_content($content){
if(!preg_match("|<!--ff_fquick-->|",$content))
			return $content;
	
		global $wpdb, $table_prefix;
		$table = $table_prefix."fquick";
		
		$sql = "SELECT id, description, title, url, UNIX_TIMESTAMP(date) as d FROM $table ORDER BY `id` DESC";
		$results = $wpdb->get_results($sql);

		foreach($results as $result){
			$fquick .= "<p><a href='$result->url'>$result->title</a><br/>".stripslashes($result->description)."<br/>(".date("F jS Y",$result->d).")</p>";	
		}

	
		return preg_replace("|<!--ff_fquick-->|", $fquick, $content);
		
	
	}
	// Show the content
	function fquick_get($heading = false){

		global $wpdb, $table_prefix;
		$table = $table_prefix."fquick";
		$limit = get_option('fquick_number_to_show');
		
		$asql = "SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%<!--ff_fquick-->%'";
		$id = $wpdb->get_var($asql);				

		$sql = "SELECT title, url, description, UNIX_TIMESTAMP(date) as d FROM $table ORDER BY id DESC";
		if(!$all)
			$sql .=  " LIMIT $limit";
		$fquicks = $wpdb->get_results($sql);
		

		foreach($fquicks as $fquick){
		
			$date = date("F jS Y",$fquick->d);
			
			$out .= 
			"<p class='fquick-link'>
			<a href ='".stripslashes(html_entity_decode($fquick->url))."'>".stripslashes($fquick->title)."</a></p>";
		
			$out .= 
			"<p class='fquick-desc'>".stripslashes($fquick->description)."</p>\n";		

		}
		echo $out;
		if($id){
			$permalink = get_permalink($id);
			echo "<p><a href='$permalink'>More SideNotes &raquo;</a></p>";
		}

	}
	
	// Install database table
	function fquick_jal_install() {
	
		global $table_prefix, $wpdb, $user_level;
		$table_name = $table_prefix . "fquick";
		
		get_currentuserinfo();
		if ($user_level < 8) { return; }
		
		$sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
				`id` INT( 11 ) NOT NULL AUTO_INCREMENT ,
				`url` VARCHAR( 255 ) NOT NULL ,
				`title` VARCHAR( 255 ) NOT NULL ,
				`description` TEXT NOT NULL ,
				`date` TIMESTAMP( 11 ) NOT NULL ,
				PRIMARY KEY ( `id` )
				);";

		require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
		dbDelta($sql);
	}
	
	function fquick_add_meta()
	{
		echo "<li><a href='".get_bloginfo('url')."/fquick_feed.php'>RSS SideNotes</a></li>";
	}

	// At init
	function fquick_init() {
			add_management_page('Manage fQuick', 'fQuick', '9', 'fquick-manage.php');
			add_options_page('fQuick options', 'fQuick', 9, 'fquick-options.php');
	}
	

	// Install hooks and filters	
	if (isset($_GET['activate']) && $_GET['activate'] == 'true') {
   		add_action('init', 'fquick_jal_install');

	}
	add_action('admin_menu', 'fquick_init');
    add_filter('the_content', 'fquick_the_content');
    //add_filter('admin_head', 'fquick_adminhead');
    add_filter('wp_head', 'fquick_wphead');
	add_filter('wp_meta', 'fquick_add_meta');

?>