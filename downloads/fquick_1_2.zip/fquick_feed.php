<?php
		require_once("wp-blog-header.php");
		header ("Content-type: text/xml");    
		echo ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		?>
		<rss version='2.0'>
		<channel>
		<title><?php bloginfo('name');?> - SideNotes</title>
		<description><?php bloginfo('name');?> - Feed from fQuick SideNotes.</description>
		<link><?php bloginfo('siteurl');?>/fquick_feed.php</link>
		<language>en-us</language>
		
		
		<?php
		global $wpdb, $table_prefix;
		$table = $table_prefix."fquick";

		$results = $wpdb->get_results("SELECT * FROM $table ORDER BY `id` DESC LIMIT 0,10");
		
		foreach($results as $result)
		{
			$desc = $result->description;
			$desc = str_replace("\n","<br />",$desc);
			$desc = str_replace("<", "<", $desc);
			$desc = str_replace(">", ">", $desc);
		
		echo "<item>\n
			<title>".$result->title."</title>\n
			<description>".$desc."</description>\n
			<link>".$result->url."</link>\n
			<pubDate>".date("F jS, Y", mktime(1,1,1,substr($result->date, 2,2),substr($result->date, 4,2) ,substr($result->date, 0,2)))."</pubDate>\n
			</item>\n\n";
		}
			
			
		?>
		</channel>
		</rss>
	
