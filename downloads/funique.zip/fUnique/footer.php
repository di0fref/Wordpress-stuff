<!-- begin footer -->

<div id="footer">
		<p>
			Using fUnique design by <a href="http://www.fahlstad.se/">Fredrik Fahlstad </a>
			Proudly powered by <a href="http://www.wordpress.org" title="Wordpress CMS">WordPress</a>.</p>
</div>
</div>
<?php do_action('wp_footer'); ?>

</body>
</html>
