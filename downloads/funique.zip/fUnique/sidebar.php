<div id="sidebar">
<h2>Search this site</h2>
<div id="searchdiv">

    <form id="searchform" method="get" action="/index.php">
	<input type="text" name="s" id="s" size="20"/>
     <input name="sbutt" type="submit" value="Go" alt="Submit"  />
	 </form>
  </div>			

  <h2>Feeds</h2>
	<ul id="feed">
		<li><a href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>">RSS Articles</a></li>  		
		</ul>
<h2>Monthly archives</h2>
<ul><?php wp_get_archives('type=monthly'); ?></ul>

<h2>Categories</h2>
<ul><?php wp_list_cats(); ?></ul>
</div>
