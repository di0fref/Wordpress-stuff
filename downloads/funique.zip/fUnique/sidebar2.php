<div id="sidebar2">

	<ul>
		<?php  get_links_list('id'); ?>
	</ul>
</div>
