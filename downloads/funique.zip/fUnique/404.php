<?php get_header();?>

<div id="content">
	<h3 class="entrytitle">The page you requested is no longer here [error 404] </h3>
	<p>... but we think we can help you </p>

We suggest you try one of the links below: 
<p><a href="<?php bloginfo('siteurl');?>">Home Page</a></p>
    <h4>Help us to help you ... </h4>
    <p>In order to improve our service, you can inform us that someone else has an incorrect link to our site. </p>
    <p><a href="http://www.fahlstad.se/contact">Report broken link</a> </p>
    <p>&nbsp;</p>
	  </div>
    <?php get_sidebar(); ?> 
      <?php get_footer(); ?> 
    
