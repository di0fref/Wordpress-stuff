    <?php
    // You might want to show fewer results than the standard per-page number
    $max_results = 10; 
    ?>
    <h2>Search Results</h2>
    <?php if (have_posts()) : $i = 0; ?>
    <ul>
        <?php while (have_posts()) : the_post(); $i++; ?>
        <li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a>
			
			</li>
            <?php if ($i == $max_results) break; ?>
        <?php endwhile; ?>
            
				<li class="more"><a href="<?php echo get_bloginfo('wpurl');?>/?s=<?php echo urlencode($_GET['s']); ?>">Get More 
                  Details in the Full View</a></li>
			
        </ul>

    <?php else : ?>
    <p>Sorry, nothing matched your search.</p>
    <p>&nbsp;</p>
    <?php endif; ?>


