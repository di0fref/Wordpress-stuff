<?php if (isset($_GET['ajax'])) { ?>
	<?php include(TEMPLATEPATH."/live.php");?>
<?php } else { ?>

<?php get_header();?>

<div id="content">


	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="entry">
			<h3><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title();?></a> </h3>
			<p class="meta">
				<?php the_time('F dS, Y ');?>
				<?php comments_popup_link($cil .' Comments(0)', $cil .' Comments(1)', $cil . ' Comments(%)');?>
				<?php edit_post_link(__(' Edit'));?>
			</p>			
			<?php the_content(__('Read more &raquo;'));?>
			<!--<?php trackback_rdf(); ?>-->
		</div>
	<?php endwhile; ?>
	<?php else: ?>
		<div class="entry"><?php _e('Sorry, no posts matched your criteria.'); ?></div>
	<?php endif; ?>
	<div class="entry"><?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?></div>
</div>


<?php get_sidebar(); ?>
<!-- The main column ends  -->
<?php get_footer(); ?>
<?php } ?>
