<div id="searchdiv">
<form method="get" id="searchform" action="<?php echo get_bloginfo('siteurl');?>">
<input type="text" value="" name="s" id="s" /><input type="submit" class="submit" id="searchbutton" value="Search" />
<input type="hidden" name="path" value="<?php echo get_bloginfo('siteurl');?>" id="path" />
</form>
<div id="search-results"></div>
</div>