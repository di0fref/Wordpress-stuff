
<?php get_header();?>
<div id="content">
<div class="entry">
	<?php if (have_posts()) :
	?>
	<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
	<?php 
	if (is_category()) { ?>				
		<div class="arc"><h2>Archive for the '<?php echo single_cat_title(); ?>' Category</h2></div>
	<?php }
	 
	elseif (is_day()) { ?>
		<div class="arc">Archive for <?php the_time('F jS, Y'); ?></h2></div>
	<?php }
	
	elseif (is_month()) { ?>
		<div class="arc"><h2>Archive for <?php the_time('F, Y'); ?></h2></div>
	<?php } 
	
	elseif (is_year()) { ?>
		<div class="arc"><h2>Archive for <?php the_time('Y'); ?></h2></div>
	<?php } 
	
	elseif (is_search()) { ?>
		<div class="arc"><h2>Search Results</h2></div>
	<?php } 
	
	elseif (is_author()) { ?>
		<div class="arc"><h2>Author Archive</h2></div>
	<?php }
	?></div>
	<?php
	 while (have_posts()) : the_post(); ?>
		<div class="entry">
			<h3><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title();?></a> </h3>
			<p class="meta">
				<?php the_time('F dS, Y ');?>
				<?php comments_popup_link($cil .' Comments(0)', $cil .' Comments(1)', $cil . ' Comments(%)');?>
				<?php edit_post_link(__(' Edit'));?>
			</p>			
			<?php the_content(__('Read more &raquo;'));?>
			<!--<?php trackback_rdf(); ?>-->
		</div>
	<?php endwhile; ?>
	<?php else: ?>
		<div class="entry"><?php _e('Sorry, no posts matched your criteria.'); ?></div>
	<?php endif; ?>
	<div class="entry"><?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?></div>

  <?php comments_template(); ?>
 
</div>
<?php get_sidebar(); ?>
<!-- The main column ends  -->
<?php get_footer(); ?>
