<?php
/*
Plugin Name: fMoblog
Plugin URI: http://www.fahlstad.se
Description: A plugin that lets you post images from your cell phone.
Author: Fredrik Fahlstad
Version: 2.1
Author URI: http://www.fahlstad.se
*/
$version = "2.1";
	
	// Some global stuff
	global $wpdb;
	$site = get_bloginfo('siteurl');
	$pageid = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%<!--fmoblog-->%'");
	
	
	// Put the image to database
	function fsql($imgname, $date, $sender, $subject, $message){
	
		global $wpdb, $table_prefix;
		$table = $table_prefix."images";
		$sql = "INSERT INTO $table (sixfourdata, sender, subject, date, message) VALUES ('$imgname.jpg', '$sender', '$subject', '$date', '$message')";
		$wpdb->query($sql);

	}
	// Create thumbnail
	function create_thumbnail($filename){
	
		 $original = imagecreatefromjpeg("wp-content/fmoblog_pictures/$filename.jpg");
		 $twidth = 128; 
		 $owidth = imagesx($original);
		 $oheight = imagesy($original);
		 $ratio = $owidth / $twidth;
		 $theight = $oheight / $ratio;
		 $thumbnail = imagecreatetruecolor($twidth, $theight);
		 imagecopyresampled($thumbnail, $original, 0, 0, 0, 0, $twidth, $theight, $owidth, $oheight);
		 imagejpeg($thumbnail, "wp-content/fmoblog_thumbs/t_$filename.jpg");
		 imagedestroy($original);
		 imagedestroy($thumbnail);
		 re($filename);	 
	}
	// Resize image
	function re($filename){
	
		 $original = imagecreatefromjpeg("wp-content/fmoblog_pictures/$filename.jpg");
		 
		 $twidth = get_option('fmoblog_image_width');
		 $owidth = imagesx($original);
		 $oheight = imagesy($original);
		 if($owidth > $twidth)
		 {
			 unlink("wp-content/fmoblog_pictures/$filename.jpg");
			$ratio = $owidth / $twidth;
			$theight = $oheight / $ratio;
			$thumbnail = imagecreatetruecolor($twidth, $theight);
			imagecopyresampled($thumbnail, $original, 0, 0, 0, 0, $twidth, $theight, $owidth, $oheight);
			imagejpeg($thumbnail, "wp-content/fmoblog_pictures/$filename.jpg");
			imagedestroy($original);
			imagedestroy($thumbnail);
		}
	}

	// Add quicktag
	function fmoblog_add_quicktag() {
	
		if(strpos($_SERVER['REQUEST_URI'], 'post.php') || strpos($_SERVER['REQUEST_URI'], 'page-new.php')) {
		
			?><script language="JavaScript" type="text/javascript"><!--
			var toolbar = document.getElementById("ed_toolbar");
			<?php edit_insert_button("fMoblog", "fmoblog_handler", "fMoblog");?>
			var state_my_button = true;
			function fmoblog_handler(){
			
				if(state_my_button) {
				
						edInsertContent(edCanvas, '<!-'+'-fmoblog-'+'->');
				}
			}
			//--></script>
			<?php
		}	
	}

	// Insert quicktag
	if(!function_exists('edit_insert_button')) {
	
		function edit_insert_button($caption, $js_onclick, $title = '') {
		?>
			if(toolbar) {
					var theButton = document.createElement('input');
					theButton.type = 'button';
					theButton.value = '<?php echo $caption; ?>';
					theButton.onclick = <?php echo $js_onclick; ?>;
					theButton.className = 'ed_button';
					theButton.title = "<?php echo $title; ?>";
					theButton.id = "<?php echo "ed_{$caption}"; ?>";
					toolbar.appendChild(theButton);
			}
			<?php
		}
	}
	function rename_win($oldfile,$newfile) {
		if (!rename($oldfile,$newfile)) {
			if (copy ($oldfile,$newfile)) {
				unlink($oldfile);
			return TRUE;
			}
			return FALSE;
		}
	return TRUE;
	}
	
	
	// get the mail
	function fmoblog_getmail(){
	global $site;
		$MAIL_SERVER = get_option('fmoblog_mailserver');
	    $MAIL_USERNAME = get_option('fmoblog_mailuser');
	    $MAIL_PASSWORD = get_option('fmoblog_mailpass');
	    $SHARED_EMAIL = FALSE;
		$PICTURE_FOLDER = "wp-content/fmoblog_pictures";
	    $ALLOWED_SENDERS = "@";

    	$BLOG_URL = "http://" . preg_replace("/index.php/", "", $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF']);

		// open mailbox and get emails from server
       if (! $mail = imap_open( "{" . $MAIL_SERVER . ":110/pop3/notls}INBOX", $MAIL_USERNAME, $MAIL_PASSWORD))
            die("could not connect to mailserver. quitting ...");
        $headerstrings = imap_headers($mail);

        foreach ($headerstrings as $headerstring) {
		
            $multipart = FALSE;
            $imagecounter = 1;
            preg_match("/[0-9]/", $headerstring, $number);

			// parse message and sender
            $header = imap_fetchheader($mail, $number[0]);
            preg_match("/Date: (.*)?[\+|-]/", $header, $date);
            $date = htmlentities($date[1]);
			$date = strtotime($date);
			$date = date("Y-m-d", $date);
            $headerinfo = imap_headerinfo($mail, $number[0], 256, 256);
            $email = " (".$headerinfo->from[0]->mailbox . "@" . $headerinfo->from[0]->host.")";
            $decode = imap_mime_header_decode($headerinfo->from[0]->personal);
            $sender = $decode[0]->text;
            $sender .= $email;
            $decode = imap_mime_header_decode($headerinfo->fetchsubject);
            $subject = $decode[0]->text;
            $imap = imap_fetchstructure($mail, $number[0]);
            if (! empty($imap->parts)) {
			
                for($i = 0, $j = count($imap->parts); $i < $j; $i++) {
				
                   $msg = imap_fetchbody($mail, $number[0], $i + 1);
                   $part = $imap->parts[$i];
					// save image
					if ($part->disposition == ATTACHMENT || $part->type == TYPEIMAGE || ($part->type == TYPEAPPLICATION && $part->subtype <> "SMIL")) 
					{
						if ($part->subtype == "JPEG" || $part->subtype == "jpg" || $part->subtype == "jpeg" || $part->subtype == "JPG") 
						{
							if (! $handle = @fopen("$PICTURE_FOLDER/" . md5($date) . "_$imagecounter.jpg", "w"))
							{
								die("no permission to write image. quitting ... $PICTURE_FOLDER");
							}
							fwrite($handle, imap_base64($msg));
							fclose($handle);
							for($i = 0; $i < 50; ++$i);
							$imgname = str_replace(".", "", array_sum(explode(" ",microtime())));
							
							// *nix servers use below
							rename("$PICTURE_FOLDER/" . md5($date) . "_$imagecounter.jpg", "$PICTURE_FOLDER/$imgname.jpg");
							
							// Windows servers use below 
							//rename_win("$PICTURE_FOLDER/" . md5($date) . "_$imagecounter.jpg", "$PICTURE_FOLDER/$imgname.jpg");
							
							// VERSION 2.0 
							/**************************************************************************/
							// Extract message							
 							$body = imap_body($mail, $number[0]);           	
							if (preg_match("/=23/", $body))
								preg_match("/=23(.*)=23/Ums", $body, $m);
							else
								preg_match("/#(.*)#/Ums", $body, $m);
							
							// handle soft and hard CRs
							$m[1] = preg_replace("/ \r\n/", " ", trim($m[1]));
							$m[1] = preg_replace("/\n/", "<br />", trim($m[1]));
							
							// decode message according to charset
							if (preg_match("/=C3/", $m[1]))
								$m[1] = utf8_decode(quoted_printable_decode($m[1]));
							else
								$m[1] = quoted_printable_decode($m[1]);
							
							$m[1] = preg_replace("/ = /", " ", $m[1]);
							fsql($imgname, $date, $sender, addslashes($subject), $m[1]);
							create_thumbnail($imgname);
							/**************************************************************************/							
						}
                    }
                }  
            }
            else
               $body = imap_body($mail, $number[0]);
			// write message, author and date into appropriate arrays
             imap_delete($mail, $number[0]);
        }
		// delete all read emails from server and close connection
		imap_expunge($mail);
		imap_close($mail);               
	}

    function fmoblog_the_content($content){	
		if(!preg_match("|<!--fmoblog-->|",$content))
			return $content;
			
			
		global $wpdb, $table_prefix, $site, $pageid, $page_id;
		$table = $table_prefix."images";
		
		
		 //Check mailbox if imap_open exists
		if (function_exists('imap_open')) {

				// Check update interval
				$now = time();
				$nextupdate = (get_option('fmoblog_update')*60) + (get_option('fmoblog_timestamp'));
				
				if($now > $nextupdate){
					
					//Update next update-time
					update_option('fmoblog_timestamp', time());
					fmoblog_getmail();
				}
		}

		else{
			echo "<div id='fmoblog_error'>There is a problem with <b>fMoblog</b> Your host seem to be missing the <a href='http://se2.php.net/manual/en/function.imap-open.php'>imap_open</a> function in their PHP installation. This means that fMoblog will not work as intended. No e-mails will be read and no images will show. Maybe you can talk to your host and ask them to fix this problem.</div>";
		}

		
		if (isset($_GET['id'])){
		
			global $userdata;
			get_currentuserinfo();
			$idsresult = $wpdb->get_row("SELECT * FROM $table WHERE imgid = $_GET[id]");
			$bdate = date("j F, Y", strtotime($idsresult->date));
			$link_date = date("Y-m", strtotime($idsresult->date));
   			$fblog .=  "<div id='fmoblog'><h3>".stripslashes($idsresult->subject)."</h3>";
			$fblog .= "<p>$bdate</p>";
			$fblog .= "<a href='$site/?page_id=$pageid&amp;date=";
			$fblog .= $link_date;
			$fblog .= "'><img src='$site/wp-content/fmoblog_pictures/$idsresult->sixfourdata' alt='Click image to go back to thumbnails.'/>
						</a><p><b>Description:</b> ".stripslashes($idsresult->message)."</p>";
			
			$fblog .= "</div>";					
		}
		
		else{
	
			if(isset($_GET['date'])){
		
				$da = strtotime($_GET['date'], time());
				$da = $_GET['date'];
			}
			
			else
				$da = date("Y-m", time());

			$dm = explode("-", $da); $gallery = date("F Y", mktime(0,0,0,$dm[1],1, $dm[0])); 
			$fblog .= "<div id='fmoblog_photolist'>\n";
			$newdate = "";	
			
			$fblog .= "<form action='$site/?page_id=$pageid' method='get' >\n";
			$fblog .= "<input type='hidden' name='page_id' value='$pageid' />\n";
			$fblog .= "<select name='date'>\n";
		
			$imgresults = $wpdb->get_results("SELECT * FROM $table WHERE date LIKE '%$da%' ORDER BY imgid DESC");
			$listresults = $wpdb->get_results("SELECT DISTINCT DATE_FORMAT(date,'%Y-%m') as dates, count(date) as counts, imgid FROM $table GROUP BY dates ORDER BY imgid DESC");
		
			foreach((array)$listresults as $listresult){
			
				$str = explode("-", $listresult->dates);
				$a = date("F", mktime(0,0,0,$str[1],1, $str[0]));
				$fblog .= "<option value='$listresult->dates'>$a $str[0] ($listresult->counts)</option>\n";
				$newdate = $str[0];
			}
		
			$fblog .= "</select><input type='submit' value='Go' /></form>";
			$fblog .= "</div>\n<div id='fmoblog_photodate'>\n<h3>$gallery</h3>\n</div>\n";

			$fblog .= "<div style='clear:both; height:1px;'></div><div id='fmoblog'>";
		
			if ($imgresults){
		  
				foreach((array)$imgresults as $img){
			  
					$fblog .= "<a href='$site/?page_id=$pageid&amp;id=$img->imgid'>
							<img src='$site/wp-content/fmoblog_thumbs/t_$img->sixfourdata' alt='".htmlentities ($img->subject, ENT_QUOTES)."' border='0'/></a>";
				}
			}
			else
				$fblog .= "<p>No pictures this month, please check out the archives.</p>";
	
			$fblog .= "</div>";
		}	



				// Some credit
		
		$fblog .= "<p><a href='http://www.fahlstad.se'>Gallery powered by fMoblog $version</a></p>";

		return preg_replace('|<!--fmoblog-->|', $fblog, $content);
}
		
		
	function fmoblog_get_latest($heading = true ){

		global $wpdb, $table_prefix, $site, $pageid;
		$table = $table_prefix."images";

		$link = $wpdb->get_row("SELECT ID FROM $wpdb->posts WHERE post_content LIKE '%<!--fmoblog-->%'");

		$pcs = get_option('fmoblog_latest_numbers');
		$latest = $wpdb->get_results("SELECT * FROM $table ORDER BY imgid DESC LIMIT $pcs");
	                if($heading == true)
		$late .= "<div id='fmoblog'>";

		foreach((array)$latest as $l){
		
			$late .= "
			<a href='$site/?page_id=$link->ID&amp;id=$l->imgid'>
			<img src='$site/wp-content/fmoblog_thumbs/t_$l->sixfourdata' width='".get_option('fmoblog_thsize')."'alt='".htmlentities($l->subject, ENT_QUOTES)."' /></a>";
			
		}
		echo "$late</div>";
		//return preg_replace('|<!--fmoblog_latest-->|', $late, $content);
	}
	
	// Get a picture from database for inclusion in a post.
	function fmoblog_get_img($image, $thumb = false, $align = 'default')
	{
		global $wpdb, $table_prefix, $site;
		$table = $table_prefix."images";
		$sql = "SELECT subject FROM $table WHERE sixfourdata = '$image'";
		$res = $wpdb->get_row($sql);
		if($thumb)
			echo "<img src='$site/wp-content/fmoblog_thumbs/t_$image' align ='$align' alt='".htmlentities ($res->subject, ENT_QUOTES)."'/>";	
		else
			echo "<img src='$site/wp-content/fmoblog_pictures/$image' align ='$align' alt='".htmlentities ($res->subject, ENT_QUOTES)."'/>";
	}

	function fmoblog_css()
	{
		?>
		<style type="text/css" media="screen">
		#fmoblog_side{
		}
		#fmoblog{
					margin-top:10px;

		}

		#fmoblog_side img, #fmoblog img{
			border:1px #ccc solid;
			padding:1px;
			margin:1px;
			background-color:#fff;
		}
		#fmoblog_photodate {
			height:50px;
			float:left;
		}
		#fmoblog_photolist {
			float: right;
			margin: 0;

			margin-left: 0;
			padding: 0;

		}
		#fmoblog a,
		#fmoblog a:visited,
		#fmoblog a:hover,
		#fmoblog a:focus {
			border:none;
			text-decoration:none;
			background-color:transparent;
		}
		#fmoblog_error{
			background-color:#FF0000;
			border:3px #000000 solid;
		}
		</style>
<?php
}


// create new table
function jal_install () {

   global $table_prefix, $wpdb, $user_level;
   $table_name = $table_prefix . "images";
   get_currentuserinfo();

   if ($user_level < 8) { return; }
	else{
   		$sql = "CREATE TABLE ".$table_name." (
   			imgid smallint(11) NOT NULL auto_increment,
  			sixfourdata varchar(255) default NULL,
  			date date default NULL,
  			sender varchar(255) default NULL,
  			subject varchar(255) default NULL,
			message TEXT,
  			UNIQUE KEY id (imgid)
		   );";
	}
	
    require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
    dbDelta($sql);
		
    if($wpdb->get_var("show tables like '$table_name'") != $table_name) {

		$welcome_name = "Mr. Wordpress";
		$welcome_text = "Congratulations, you just completed the installation!";
	}
}

	
	function fmoblog_init() 
	{
    	if (function_exists('add_options_page')) 
		{
			add_options_page('fMoblog options', 'fMoblog', 9, 'fmoblog_options.php');
			add_management_page('Manage fMoblog', 'fMoblog', '9', 'fmoblog-manage.php');

    	}
	}
	
	if (isset($_GET['activate']) && $_GET['activate'] == 'true') {
	
   		add_action('init', 'jal_install');
	}
	if(get_option('fmoblog_show_quick') == true) {
	
		add_action('admin_footer', 'fmoblog_add_quicktag');
	}
	add_action('admin_menu', 'fmoblog_init');
    add_filter('the_content', 'fmoblog_the_content');
	//add_action('wp_meta', 'fmoblog_get_latest');
    add_filter('wp_head', 'fmoblog_css');
	
	

	?>
