<?php
	$path = get_option('siteurl') . '/wp-admin/admin.php?page=fmoblog-manage.php'; // Form Action URI
	global $wpdb, $table_prefix;
	$table = $table_prefix."images";
	
	$PICTURE_FOLDER = "../wp-content/fmoblog_pictures";
	$THUMBS_FOLDER = "../wp-content/fmoblog_thumbs";

	// Add to database
	function fmoblog_add_to_db($imgname, $date, $sender, $subject, $message)
	{
		global $wpdb, $table_prefix;
		$table = $table_prefix."images";
		$sql = "INSERT INTO $table (sixfourdata, sender, subject, date, message) VALUES ('$imgname.jpg', '$sender', '$subject', '$date', '$message')";
		$wpdb->query($sql);
		m_create_thumbnail($imgname);
	}

	// Create thumbnail
	function m_create_thumbnail($filename){
		
		global $THUMBS_FOLDER, $PICTURE_FOLDER;
		$original = imagecreatefromjpeg("$PICTURE_FOLDER/$filename.jpg");
		$twidth = 128; 
		$owidth = imagesx($original);
		$oheight = imagesy($original);
		$ratio = $owidth / $twidth;
		$theight = $oheight / $ratio;
		$thumbnail = imagecreatetruecolor($twidth, $theight);
		imagecopyresampled($thumbnail, $original, 0, 0, 0, 0, $twidth, $theight, $owidth, $oheight);
		imagejpeg($thumbnail, "$THUMBS_FOLDER/t_$filename.jpg");
		imagedestroy($original);
		imagedestroy($thumbnail);
		m_re($filename);	 
	}
	// Resize image
	function m_re($filename){

		global $THUMBS_FOLDER, $PICTURE_FOLDER;
		$original = imagecreatefromjpeg("$PICTURE_FOLDER/$filename.jpg");
		 
		 $twidth = get_option('fmoblog_image_width');
		 $owidth = imagesx($original);
		 $oheight = imagesy($original);
		 if($owidth > $twidth)
		 {
			 unlink("$PICTURE_FOLDER/$filename.jpg");
			$ratio = $owidth / $twidth;
			$theight = $oheight / $ratio;
			$thumbnail = imagecreatetruecolor($twidth, $theight);
			imagecopyresampled($thumbnail, $original, 0, 0, 0, 0, $twidth, $theight, $owidth, $oheight);
			imagejpeg($thumbnail, "$PICTURE_FOLDER/$filename.jpg");
			imagedestroy($original);
			imagedestroy($thumbnail);
		}
	}
	


	if(isset($_POST['fmoblog_upload']))
	{
		$sender = addslashes($_POST['fmoblog_sender']);
		$title = addslashes($_POST['fmoblog_title']);
		$desc = addslashes($_POST['fmoblog_desc']);
		$date = date("Y-m-d", time());
		
		
		// Get the image
		if(is_uploaded_file($_FILES["fmoblog_image"]["tmp_name"]))
		{
			if(move_uploaded_file($_FILES["fmoblog_image"]["tmp_name"], $PICTURE_FOLDER."/".$_FILES["fmoblog_image"]["name"])) 
			{
				$imgname = str_replace(".", "", array_sum(explode(" ",microtime())));
				rename("$PICTURE_FOLDER/".$_FILES["fmoblog_image"]["name"], "$PICTURE_FOLDER/$imgname.jpg");
				echo "<div class='updated'><p>File uploaded successfully.</p></div>";
			}
			else  
				echo "<div><p>ERROR: Unable to upload file.</p></div>";
		}
		else 
			echo "<div><p>ERROR: Unable to upload file.</p></div>";
					
		fmoblog_add_to_db($imgname, $date, $sender, $title, $desc);
	}
		/***********************************************************************************
			Delete image
		***********************************************************************************/	
		if(isset($_POST['fmoblog_delete']))
		{
		
			global $table_prefix, $wpdb, $page_id;
			$table = $table_prefix."images";
			$imgid = $_POST['fmoblog_delete_id'];

			$sql_get = "SELECT sixfourdata FROM $table WHERE imgid = '$imgid'";			 
			$image_path = $wpdb->get_row($sql_get);
			
			$sql_del = "DELETE FROM $table WHERE imgid = '$imgid'";
			$wpdb->query($sql_del);
			
			$img = "$PICTURE_FOLDER/".$image_path->sixfourdata;
			$thumb = "$THUMBS_FOLDER/t_".$image_path->sixfourdata;
			unlink($img);
			unlink($thumb);	
		}
		/***********************************************************************************
			Update image
		***********************************************************************************/	
		if(isset($_POST['fmoblog_do_edit']))
		{
			$title = addslashes($_POST['fmoblog_title']);
			$desc = addslashes($_POST['fmoblog_desc']);
			$sender = addslashes($_POST['fmoblog_sender']);
			$id = $_POST['fmoblog_do_edit_id'];
		
			$sql = "UPDATE $table SET 
							subject = '$title', 
							message = '$desc', 
							sender = '$sender' 
						WHERE imgid = '$id'";
			$wpdb->query($sql);
	}

	?>
	<div class='wrap'>
	<?php
		if(!isset($_POST['fmoblog_edit'])) {
			echo "<h2>fMoblog - Add image</h2>";
		}
		
		else {
			echo "<h2>fMoblog - Edit image</h2>";
			$sql_edit = "SELECT * FROM $table WHERE imgid = $_POST[fmoblog_edit_id]";
			$fmoblog_edit_row = $wpdb->get_row($sql_edit);
		}
	?>
	
		<form action="<?php echo $path ?>" method="post" enctype="multipart/form-data">


			<fieldset name="set1"></legend>
				<table width="200" border="0">
					<tr>
						<td><div align="right"><strong>Title:</strong></div></td>
						<td><input name="fmoblog_title" id="fmoblog_title" value="<?php echo $fmoblog_edit_row->subject;?>" size="32" /></td>
					</tr>
					<tr>
						<td><div align="right"><strong>Sender:</strong></div></td>
						<td><input name="fmoblog_sender" id="fmoblog_sender" value="<?php  echo $fmoblog_edit_row->sender;?>" size="32"/></td>
					</tr>
					<tr>
						<td height="24" valign="top"><div align="right"><strong>Description:</strong></div></td>
						<td><textarea name="fmoblog_desc" cols="30" rows="4" id="fmoblog_desc"><?php  echo $fmoblog_edit_row->message;?></textarea></td>
					</tr>
					<?php if(!isset($_POST['fmoblog_edit'])) { ?>
					
						<tr><td height="24" valign="top"><div align="right"><strong>Image:</strong></div></td>
						<td><input type="file" name="fmoblog_image"></td></tr>
					
					<?php } ?>
				  
				</table>
			</fieldset>
				<div class="submit">
					
				<?php if(!isset($_POST['fmoblog_edit'])) 
				echo "<input type='submit' name='fmoblog_upload' value='Upload image &raquo;'/>";
			else
				echo "<input type='submit' name='fmoblog_do_edit' value='Update image &raquo;'/>
					<input type='hidden' name='fmoblog_do_edit_id' value='$fmoblog_edit_row->imgid' />";

		?>		

				</div>
	  </form>
	  
	  <?php
	  if(!isset($_POST['fmoblog_edit']))
	  {
	  	global $wpdb, $table_prefix;
		$table = $table_prefix."images";
		$alternate = 0;

		$sql = "SELECT * FROM $table ORDER BY date DESC";
		$results = $wpdb->get_results($sql);
		echo "<h2>All images</h2>";	
		echo "<table border = '0' width='100%' cellpadding='3' cellspacing='3'>
				  <tr>
				  	<td>Image</td>
					<td>Title</td>
					<td>Description</td>
					<td colspan='4'>Date</td>
				  </tr>";

		foreach((array)$results as $result)
		{ 
			if($alternate%2 == 0)
				echo "<tr class='alternate'>";
			else
				echo "<tr class=''>";

			echo
				"<td><img src='/wp-content/fmoblog_thumbs/t_$result->sixfourdata'></td>
				<td>$result->subject</td>
				<td>$result->message</td>
				<td>$result->date</td>
									<td>
					<form action='$path' method='post'>
						<input type='submit' name='fmoblog_edit' value='Edit'/>
						<input name='fmoblog_edit_id' type='hidden' value='$result->imgid'/>
					</form>
					</td>
					<td>
					<form action='$path' method='post'>
						<input type='submit' name='fmoblog_delete' value='Delete'/>
						<input name='fmoblog_delete_id' type='hidden' value='$result->imgid'/>
					</form>
					</td>

			</tr>";
			++$alternate;
			}
			echo "</table></div>";
 
	  }
	 function fmoblog_admin_head()
	  {
	  	?>
			<script language='javascript' type='text/javascript'>
				function check_delete()
				{
					var agree = confirm('Do you really want to delete this image?');
					if(agree)
						return true;
					else
						return false;
				}
			</script> 
			<?php
	  }
	  add_action('admin_head', fmoblog_admin_head);
	  ?>