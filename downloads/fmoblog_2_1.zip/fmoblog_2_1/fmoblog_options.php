<?php
/*
Author: Fredrik Fahlstad
*/

$location = get_option('siteurl') . '/wp-admin/admin.php?page=fmoblog_options.php'; // Form Action URI

/*Lets add some default options if they don't exist*/
add_option('fmoblog_mailpass', 'Mail server password');
add_option('fmoblog_mailuser', 'Mail server username');
add_option('fmoblog_mailserver', 'mail@server.com');
add_option('fmoblog_show_quick', TRUE);
add_option('fmoblog_image_width', '480');
add_option('fmoblog_latest_numbers', '6');
add_option('fmoblog_update', '10');
add_option('fmoblog_timestamp', time());
add_option('fmoblog_thsize', '64');


		if (isset($_POST['info_update'])) 
		{
		
			/* Update options */
			update_option('fmoblog_mailpass', $_POST['fmoblog_mailpass']);
			update_option('fmoblog_mailuser', $_POST['fmoblog_mailuser']);
			update_option('fmoblog_mailserver', $_POST['fmoblog_mailserver']);
			update_option('fmoblog_image_width', $_POST['fmoblog_image_width']);
			update_option('fmoblog_latest_numbers', $_POST['fmoblog_latest_numbers']);
			update_option('fmoblog_update', $_POST['fmoblog_update']);
			update_option('fmoblog_thsize', $_POST['fmoblog_thsize']);
			
			if(isset($_POST['fmoblog_show_quick'])) {
				update_option('fmoblog_show_quick', true);
			}
			else {
				update_option('fmoblog_show_quick', false);
			}

			
			?>
			<div class="updated">
			  <p>Options sucessfully updated.</p>
			</div>
			<?php 
		} 
		
		$fmoblog_mailpass = stripslashes(get_option('fmoblog_mailpass'));
		$fmoblog_mailuser = stripslashes(get_option('fmoblog_mailuser'));
		$fmoblog_mailserver = stripslashes(get_option('fmoblog_mailserver'));
		$fmoblog_show_quick = stripslashes(get_option('fmoblog_show_quick'));
		$fmoblog_image_width = stripslashes(get_option('fmoblog_image_width'));
		$fmoblog_latest_numbers = stripslashes(get_option('fmoblog_latest_numbers'));
		$fmoblog_update = stripslashes(get_option('fmoblog_update'));
		$fmoblog_timestamp = stripslashes(get_option('fmoblog_timestamp'));
		$fmoblog_thsize = stripslashes(get_option('fmoblog_thsize'));
		
		
	
?>			
			<div class=wrap>
			  <form method="post" action="">
				<h2>fMoblog Options</h2>
				<fieldset name="set2">
				<legend>
				<?php _e('Email server option', 'Localization name') ?>
				</legend>
				<table border="0" cellpadding="2">
				  <tr>
					<td width="202">&nbsp;</td>
					<td width="475">&nbsp;</td>
				  </tr>
				  <tr>
					<td><div align="right"><strong>Mailserver:</strong></div></td>
					<td><input name="fmoblog_mailserver" type="text" id="fmoblog_mailserver" value="<?php echo $fmoblog_mailserver;?>" size="32" /> 
					(Not your email address)</td>
				  </tr>
				  <tr>
					<td><div align="right"><strong>Username:</strong></div></td>
					<td><input name="fmoblog_mailuser" type="text" id="fmoblog_mailuser" value="<?php echo $fmoblog_mailuser;?>" size="32"/></td>
				  </tr>
				  <tr>
					<td><div align="right"><strong>Password:</strong></div></td>
					<td><input name="fmoblog_mailpass" type="text" id="fmoblog_mailpass" value="<?php echo $fmoblog_mailpass;?>" size="32"/></td>
				  </tr>
				  <tr>
				    <td><div align="right"><strong>Image width: </strong></div></td>
				    <td><input name="fmoblog_image_width" type="text" id="fmoblog_image_width" value="<?php echo $fmoblog_image_width;?>" size="10"/>
				      Pixels</td>
			      </tr>
				  <tr>
				    <td><div align="right"><strong>Numbers for latest: </strong></div></td>
				    <td><input name="fmoblog_latest_numbers" type="text" id="fmoblog_latest_numbers"  value="<?php echo $fmoblog_latest_numbers;?>" size="10"/></td>
			      </tr>
				  <tr>
				    <td><div align="right"><strong>Update interval: </strong></div></td>
				    <td><input name="fmoblog_update" type="text" id="fmoblog_update"  value="<?php echo $fmoblog_update;?>" size="10"/> 
				      Minutes </td>
			      </tr>
				  <tr>
				    <td><div align="right"><strong>Thumbnail width sidebar: </strong></div></td>
				    <td><input name="fmoblog_thsize" type="text" id="fmoblog_thsize"  value="<?php echo $fmoblog_thsize;?>" size="10"/> 
			        Pixels </td>
			      </tr>
				  <tr>
					<td>&nbsp;</td>
					<td><input type="checkbox" name="fmoblog_show_quick" value="fmoblog_show_quick" 
					<?php if($fmoblog_show_quick == TRUE) {?> checked="checked" <?php } ?>	/>
				     Show Quicktag </td>
				  </tr>
				</table>
				</fieldset>
				<div class="submit">
				  <input type="submit" name="info_update" value="<?php
					_e('Update options', 'Localization name')
					?> �" />
				</div>
			  </form>
			</div>
			<?php

?>
