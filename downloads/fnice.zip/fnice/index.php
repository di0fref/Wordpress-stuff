<?php get_header(); ?>

<div id="content">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="entry">
				<h2 class="entrydate"><?php the_date() ?></h2>
  <h3 class="entrytitle" id="post-<?php the_ID(); ?>"> <a href="<?php the_permalink() ?>" rel="bookmark">
    <?php the_title(); ?>
    </a> </h3>
  <div class="entrybody">
    <?php if(is_home()){
			 the_excerpt(); 
		}
		else
			the_content(__('(more...)')); 
		?>
	
	

	
	   <div class="entrymeta"> 
      
      <?php the_time('F dS Y') ?>
      Posted to
      <?php the_category(',') ?>
      <?php edit_post_link(__('<strong>Edit</strong>')); ?>
    </div>

    
	<p class="comments_link">
      <?php 
		$comments_img_link = '<img src="' . get_stylesheet_directory_uri() . '/images/comments.gif"  title="comments" alt="*" />';
		comments_popup_link(' Comments(0)', $comments_img_link . ' Comments(1)', $comments_img_link . ' Comments(%)'); 
	?>
	
    </p>
  </div>
  <!--
	<?php trackback_rdf(); ?>
	-->
</div>
<?php comments_template(); // Get wp-comments.php template 
if(is_home()) break;
 endwhile; else: ?>
<p>
  <?php _e('Sorry, no posts matched your criteria.'); ?>
</p>

<?php 
endif; ?>

<?php
if(!is_home()) ?>
<p>
              <?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?>
</p>

<?php if(is_home()){ ?>

<?php 
// Unncomment this if you have the fMoblog plugin
 //fmoblog_get_latest();?>
<div id="recent"> 

<h2 class="res">Recent entries</h2>
<?php
 $posts = get_posts('numberposts=5&offset=1');
 foreach($posts as $post) :
 setup_postdata($post);
 ?>
    <h3><a href="<?php the_permalink(); ?>" id="post-<?php the_ID(); ?>"><?php the_title(); ?></a></h3>
	<p><?php the_time('F dS Y'); ?> | <?php the_category(',') ?></p>

 <?php endforeach; ?>
  </div>
  
  <div id="recentcomm">
  <h2 class="res">Recent comments</h2>
  <?php 
  global $wpdb, $table_prefix;
  $table = $table_prefix."comments";
  $sql = "SELECT * FROM $table ORDER BY comment_date DESC LIMIT 5";
  $comms = $wpdb->get_results($sql);
  foreach((array)$comms as $comm) {
  	
	echo "<a href='".get_permalink($comm->comment_post_ID)."#comment$comm->comment_ID'> $comm->comment_author</a>: ".htmlentities (substr($comm->comment_content,0,100))."...<br/>\n";

  }
  ?>
  </div>
  
 <?php } ?>
 </div>
<?php get_sidebar(); ?>
<!-- The main column ends  -->

<?php get_footer(); ?>
